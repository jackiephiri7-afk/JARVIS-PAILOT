# JARVIS — PAILOT

A starter Android personal-assistant app.

## Included
- Android chat interface
- Gemini API chat (API key entered by the user; not saved by this app)
- Speech-to-text using Android's speech recognizer
- Spoken replies using Android Text-to-Speech

## Important limitations
- This is a starter app, not a finished Iron Man-style assistant.
- It does not independently control other phones, bypass permissions, or read private messages.
- A direct API key in a mobile app is suitable only for a personal prototype. For a public release, put AI requests behind a secure backend and never publish your key.
- API usage may incur charges according to the provider's terms.

## Build
Open this project in Android Studio with Android SDK 35 and JDK 17, then run:

```bash
gradle assembleDebug
```

The APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

Package name: `com.pilot.jarvis`
